TechnoTales: Tech News Document Retrieval System

TechnoTales is a Tech News document retrieval system that allows users to search for relevant tech news articles. 
The project consists of a frontend (Client) and a server (Search_Engine_Server) that hosts an Information Retrieval (IR) system.

We Scraped the "TechCrunch" Website for the required dataset. 

---------------------------------------------------------------------------------------------

You may find the dataset and JSON Files in the below drive link
`https://drive.google.com/drive/folders/1Ur8HQk1NKTQeNKlzVhQnLS3_s1YTenGQ?usp=sharing`

*****Note: Please Download All the 7 JSON files present in "JsonFiles" folder from above drive link.

Please place those 7 files, inside the folder named "JsonFiles" in "IRDataset" folder that is present in "Search_Engine_Server" folder in "source code" folder.

Those files are mandatory for functioning of the IR System.

----------------------------------------------------------------------------------------------

Open the "source code" folder ( Preferred to use VSCode )
It contains 2 folders named "client" (Frontend) and "Search_Engine_Server" (Server)

-> Execute the following commands to run the project:

SERVER : 

1.)Navigate to the Search_Engine_Server folder using the command -
        ```bash
            cd Search_Engine_Server
        ```

2.) Please check your pip version using the command - "python -m pip --version". 
    Also sometimes you need to use "pip3" or "python3" instead of "pip" or "python". (Based on python installed in your system)


3.) If the pip version is not 23.3.1 . 
    Please Upgrade it to 23.3.1 using the command - 
    "python.exe -m pip install --upgrade pip"  (or) "python.exe -m pip install --upgrade pip --user"

4.) Install the required Python packages using the command -
      
         ```bash
            pip install -r requirements.txt --user
         ```
5.) Run the main server file using the command -
        ```bash
            python Server.py
        ```
6.) Allow the server, (B/w 90-100 Seconds) to load all the files.

7.) Until then you can start setting up the Front-end part.


-----------------------------------------------------------------------------------------------
Open new Terminal in "source code" folder and follow the below commands.

FRONT-END : (***Note : You need to have NodeJS , installed in your System)
 
1.) Navigate to the client folder using the command - 
        ```bash
            cd client
        ```
2.) Install the required Node.js modules using the command - 
        ```bash
           npm install
        ```
3.) Start the React application using the command -
         ```bash
           npm start
        ```
4.) Open the link `http://localhost:3000/` in a web browser, and you can start searching for queries.

5.) Make sure the server is ready to accept the requests. 
        (
            You will see a message in the terminal like 
                "The Files are Loaded in to the Server.....
                  * Debugger is active!
                  * Debugger PIN: 501-072-087 ". This indicates that server is ready to serve requests. 

            Please give the query input in the frontend, after you see this message pop-up in the terminal
        )
                                                  
----------------------------------------------------------------------------------------------

SEARCHING FOR QUERIES :

1.) Enter your query in the search bar.
2.) Wait for the results to be displayed (approximately 10-11 seconds).
3.) The top 10 search results with links to the original documents will be provided.
4.) Provide relevance feedback for every document displayed.(By clicking the Like and dislike symbol that appears on left of each link, when you open the link). 
5.) I have considered explicit User Relavance feedback. So until the User gives the feedback to all 10 documents, P-R Curve will not be generated.

-----------------------------------------------------------------------------------------------

EVALUATION :

1.)In the top right corner, you can find a button named "P-R Curve", Click the button to see the Precision-Recall (P-R) curve generated during the evaluation.
2.)Explore the curve to understand the performance of the information retrieval system.


-----------------------------------------------------------------------------------------------
                 

